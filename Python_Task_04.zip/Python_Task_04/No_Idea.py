# HackerRank = https://www.hackerrank.com/challenges/no-idea/problem

m, n = map(int,input().split())

arr = list(map(int,input().split()))

set_a = set(map(int,input().split()))
set_b = set(map(int,input().split()))

Total_Happiness = 0

for i in arr:
    if i in set_a:
        Total_Happiness += 1
    elif i in set_b:
        Total_Happiness -= 1

print(Total_Happiness)
