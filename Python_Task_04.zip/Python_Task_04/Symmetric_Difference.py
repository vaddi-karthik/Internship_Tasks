# HackerRank = https://www.hackerrank.com/challenges/symmetric-difference/problem

size_set_a = int(input())
set_a = set(map(int, input().split()))
size_set_b = int(input())
set_b = set(map(int, input().split()))

lst = list(set_a ^ set_b)
lst.sort()

for i in lst:
    print(i)