# HackerRank = https://www.hackerrank.com/challenges/py-set-add/problem

n = int(input())
s = set()
for i in range(n):
    x = input()
    s.add(x)
print(len(s))