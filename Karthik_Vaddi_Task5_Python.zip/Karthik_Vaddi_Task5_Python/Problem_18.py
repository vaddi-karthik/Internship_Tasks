# Problem Name = The Minion Game

# HackerRank = https://www.hackerrank.com/challenges/the-minion-game/problem

def minion_game(string):
    # your code goes here
    string = string.strip().lower()
    Stuart = 0
    Kevin = 0
    n = len(string)
    
    for i in range(n):
        point = n - i
        
        if string[i] in ['a','e','i','o','u']:
            Kevin += point 
        else:
            Stuart += point
    
    if Kevin > Stuart:
        print('Kevin', Kevin)
    elif Stuart > Kevin:
        print("Stuart",Stuart)
    else:
        print('Draw')

if __name__ == '__main__':
    s = input()
    minion_game(s)