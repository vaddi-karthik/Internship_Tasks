# Problem Name = Nested Lists

# HackerRank = https://www.hackerrank.com/challenges/nested-list/problem

if __name__ == '__main__':
    records = []

    for _ in range(int(input())):
        name = input()
        score = float(input())
        records.append([name, score])

    # Find the second lowest score
    scores = sorted({s for n, s in records})
    second_lowest = scores[1]

    # Get names with that score, sorted alphabetically
    names = sorted([n for n, s in records if s == second_lowest])

    # Print each name on a new line
    for name in names:
        print(name)