# Problem Name = Merge the Tools!

# HackerRank = https://www.hackerrank.com/challenges/merge-the-tools/problem

def merge_the_tools(string, k):
    # your code goes here
    for i in range(0, len(string), k):
        part = string[i:i+k]

        seen = set()
        result = ""

        for char in part:
            if char not in seen:
                seen.add(char)
                result += char

        print(result)
    
    

if __name__ == '__main__':
    string, k = input(), int(input())
    merge_the_tools(string, k)