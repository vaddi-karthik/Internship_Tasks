# Problem Name = Find the Runner-Up Score!

# HackerRank = https://www.hackerrank.com/challenges/find-second-maximum-number-in-a-list/problem

if __name__ == '__main__':
    n = int(input())
    arr = list(map(int, input().split()))
    second_max=sorted(set(arr))[-2]
    print(second_max)