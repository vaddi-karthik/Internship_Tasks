# Problem Name = Piling Up!

# HackerRank = https://www.hackerrank.com/challenges/piling-up/problem

t = int(input())

for _ in range(t):
    n = int(input())
    blocks = list(map(int, input().split()))

    left = 0
    right = n - 1
    current = float('inf')

    possible = True

    while left <= right:
        if blocks[left] >= blocks[right]:
            chosen = blocks[left]
            left += 1
        else:
            chosen = blocks[right]
            right -= 1

        if chosen > current:
            possible = False
            break

        current = chosen

    print("Yes" if possible else "No")