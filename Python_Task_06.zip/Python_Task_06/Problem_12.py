# Problem Name = Set .discard(), .remove() & .pop()

# HackerRank = https://www.hackerrank.com/challenges/py-set-discard-remove-pop/problem

n = int(input())
l = list (map(int, input().split()))
l.sort (reverse = True)
s=set(l)
N = int(input())

for _ in range(N):
    command = input().split()

    if command[0] == "pop":
        s.pop()
    elif command[0] == "remove":
        s.remove(int(command[1]))
    elif command[0] == "discard":
        s.discard(int(command[1]))

print(sum(s))