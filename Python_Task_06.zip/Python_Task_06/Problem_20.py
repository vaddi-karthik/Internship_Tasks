# Problem Name = Validating the Phone Number

# HackerRank = https://www.hackerrank.com/challenges/validating-the-phone-number/problem

n = int(input())

for i in range(n):
    x = input().strip()

    if x.isdigit() and len(x) == 10 and x.startswith(('7', '8', '9')):
        print("YES")
    else:
        print("NO")