# Problem Name = Set .difference() Operation

# HackerRank = https://www.hackerrank.com/challenges/py-set-difference-operation/problem

m = int(input())
s1 = set(map(int,input().split()))
n = int(input())
s2 = set(map(int,input().split()))

print(len(s1.difference(s2)))