# Problem Name = Set .union() Operation

# HackerRank = https://www.hackerrank.com/challenges/py-set-union/problem

m = int(input())
s1 = set(map(int,input().split()))
n = int(input())
s2 = set(map(int,input().split()))

count = s1.union(s2)
print(len(count))