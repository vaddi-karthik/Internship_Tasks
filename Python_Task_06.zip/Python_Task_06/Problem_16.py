# Problem Name = Check Subset

# HackerRank = https://www.hackerrank.com/challenges/py-check-subset/problem

n = int(input())

for i in range(n):
    a = int(input())
    set_A = set(map(int,input().split()))
    b = int(input())
    set_B = set(map(int,input().split()))
    
    print(set_A.issubset(set_B))