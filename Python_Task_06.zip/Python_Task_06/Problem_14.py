# Problem Name = Set .intersection() Operation

# HackerRank = https://www.hackerrank.com/challenges/py-set-intersection-operation/problem

m = int(input())
s1 = set(map(int,input().split()))
n = int(input())
s2 = set(map(int,input().split()))

print(len(s1.intersection(s2)))