# Problem Name = Company Logo

# HackerRank = https://www.hackerrank.com/challenges/most-commons/problem


s = input()
d = {}

for i in s:
    if i not in d:
        d[i] = s.count(i)

result = sorted(d.items(), key=lambda x: (-x[1], x[0]))

for char, count in result[:3]:
    print(char, count)

