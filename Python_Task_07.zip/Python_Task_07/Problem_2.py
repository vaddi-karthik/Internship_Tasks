# Problem Name = The Captain's Room

# HackerRank = https://www.hackerrank.com/challenges/py-the-captains-room/problem

from collections import Counter

n = int(input())

x = list(map(int,input().split()))

freq = Counter(x)

for i in x :
    if freq[i] == 1:
        print(i)