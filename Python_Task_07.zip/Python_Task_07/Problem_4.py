# Problem Name = Funny String

# HackerRank = https://www.hackerrank.com/challenges/funny-string/problem

#!/bin/python3

import math
import os
import random
import re
import sys

#
# Complete the 'funnyString' function below.
#
# The function is expected to return a STRING.
# The function accepts STRING s as parameter.
#

def funnyString(s):
        r = s[::-1]

        ls = [ord(i) for i in s]
        rs = [ord(i) for i in r]

        ls_diff = [abs(ls[i] - ls[i+1]) for i in range(len(ls)-1)]
        rs_diff = [abs(rs[i] - rs[i+1]) for i in range(len(rs)-1)]

        if ls_diff == rs_diff:
          return "Funny"
        else:
            return "Not Funny"


if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    q = int(input().strip())

    for q_itr in range(q):
        s = input()

        result = funnyString(s)

        fptr.write(result + '\n')

    fptr.close()
