# Problem Name = Weighted Uniform Strings

# HackerRank = https://www.hackerrank.com/challenges/weighted-uniform-string/problem

def weightedUniformStrings(s, queries):
    weights = set()
    prev = ''
    count = 0

    for ch in s:
        if ch == prev:
            count += ord(ch) - ord('a') + 1
        else:
            count = ord(ch) - ord('a') + 1
            prev = ch

        weights.add(count)

    return ['Yes' if q in weights else 'No' for q in queries]