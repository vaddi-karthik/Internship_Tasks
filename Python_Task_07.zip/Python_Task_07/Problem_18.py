# Problem Name = String Construction

# HackerRank = https://www.hackerrank.com/challenges/string-construction/problem

def stringConstruction(s):
    return len(set(s))