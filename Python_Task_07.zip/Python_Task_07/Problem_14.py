# Problem Name = Anagram

# HackerRank = https://www.hackerrank.com/challenges/anagram/problem

#!/bin/python3

import math
import os
import random
import re
import sys

#
# Complete the 'anagram' function below.
#
# The function is expected to return an INTEGER.
# The function accepts STRING s as parameter.
#

def anagram(s):
    # Write your code here
    from collections import Counter
    
    if len(s)%2 != 0:
        return -1

    mid = len(s)//2
    s1 = Counter(s[:mid])
    s2 = Counter(s[mid:])

    return sum((s1-s2).values())

if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    q = int(input().strip())

    for q_itr in range(q):
        s = input()

        result = anagram(s)

        fptr.write(str(result) + '\n')

    fptr.close()
